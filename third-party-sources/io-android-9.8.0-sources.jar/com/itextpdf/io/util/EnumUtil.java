/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.util;

import java.util.Arrays;
import java.util.List;

/**
 * This file is a helper class for internal usage only.
 * Be aware that its API and functionality may be changed in future.
 */
public final class EnumUtil {
    private EnumUtil() {
    }

    /**
     * Returns an enum value, rejecting {@code null}.
     *
     * @param enumInstance the enum value to validate
     * @param <T>          the enum type
     *
     * @return {@code enumInstance}
     */
    public static <T extends Enum<T>> T throwIfNull(T enumInstance) {
        if (enumInstance == null) {
            throw new RuntimeException("Expected not null enum instance");
        }
        return enumInstance;
    }

    /**
     * Returns all declared values of an enum type.
     *
     * @param enumInstance the enum type
     * @param <T>          the enum type
     *
     * @return a list containing the enum's declared values
     */
    public static <T extends Enum<T>> List<T> getAllValuesOfEnum(Class<T> enumInstance) {
        if (enumInstance == null) {
            throw new RuntimeException("Expected not null enum instance");
        }
        return Arrays.asList(enumInstance.getEnumConstants());
    }

}
