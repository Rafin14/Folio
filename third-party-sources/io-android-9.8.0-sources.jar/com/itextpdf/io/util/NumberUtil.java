/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.util;


/**
 * This file is a helper class for internal usage only.
 * Be aware that its API and functionality may be changed in future.
 */
public class NumberUtil {

    private NumberUtil() {
    }

    /**
     * Converts a {@link Number} to a {@link Float}.
     *
     * @param obj the number to convert, or {@code null}
     *
     * @return the float value, or {@code null} when {@code obj} is {@code null}
     */
    public static Float asFloat(Object obj) {
        Number value = (Number)obj;
        return value != null ? value.floatValue() : null;
    }

    /**
     * Converts a {@link Number} to an {@link Integer}.
     *
     * @param obj the number to convert, or {@code null}
     *
     * @return the integer value, or {@code null} when {@code obj} is {@code null}
     */
    public static Integer asInteger(Object obj) {
        Number value = (Number)obj;
        return value != null ? value.intValue() : null;
    }

}
