/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.resolver.resource;

import com.itextpdf.commons.logs.LazyLogger;
import com.itextpdf.commons.utils.MessageFormatUtil;
import com.itextpdf.io.exceptions.ReadingByteLimitException;
import com.itextpdf.io.logs.IoLogMessageConstant;
import com.itextpdf.io.util.StreamUtil;
import com.itextpdf.io.util.UrlUtil;

import java.util.HashMap;
import java.util.Map;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

/**
 * Default implementation of the {@link IResourceRetriever} interface, which can set a limit
 * on the size of retrieved resources using input stream with a limit on the number of bytes read.
 */
public class DefaultResourceRetriever implements IAdvancedResourceRetriever {
    private static final LazyLogger LOGGER = new LazyLogger(DefaultResourceRetriever.class);
    private static final int DEFAULT_CONNECT_TIMEOUT = 300_000;
    private static final int DEFAULT_READ_TIMEOUT = 300_000;
    private long resourceSizeByteLimit;
    private int connectTimeout;
    private int readTimeout;
    private Map<String, String> requestHeaders;

    /**
     * Creates a new {@link DefaultResourceRetriever} instance.
     * The limit on the size of retrieved resources is by default equal to {@link Long#MAX_VALUE} bytes.
     */
    public DefaultResourceRetriever() {
        resourceSizeByteLimit = Long.MAX_VALUE;
        connectTimeout = DEFAULT_CONNECT_TIMEOUT;
        readTimeout = DEFAULT_READ_TIMEOUT;
    }

    /**
     * Gets the resource size byte limit.
     * <p>
     * The resourceSizeByteLimit is used to create input stream with a limit on the number of bytes read.
     *
     * @return the resource size byte limit
     */
    public long getResourceSizeByteLimit() {
        return resourceSizeByteLimit;
    }

    /**
     * Sets the resource size byte limit.
     * <p>
     * The resourceSizeByteLimit is used to create input stream with a limit on the number of bytes read.
     *
     * @param resourceSizeByteLimit the resource size byte limit
     * @return the {@link IResourceRetriever} instance
     */
    public IResourceRetriever setResourceSizeByteLimit(long resourceSizeByteLimit) {
        this.resourceSizeByteLimit = resourceSizeByteLimit;
        return this;
    }

    /**
     * Gets the connect timeout.
     * <p>
     * The connect timeout is used to create input stream with a limited time to establish connection to resource.
     *
     * @return the connect timeout in milliseconds
     */
    public int getConnectTimeout() {
        return connectTimeout;
    }

    /**
     * Sets the connect timeout.
     * <p>
     * The connect timeout is used to create input stream with a limited time to establish connection to resource.
     *
     * @param connectTimeout the connect timeout in milliseconds
     * @return the {@link IResourceRetriever} instance
     */
    public IResourceRetriever setConnectTimeout(int connectTimeout) {
        this.connectTimeout = connectTimeout;
        return this;
    }

    /**
     * Gets the request headers to use in the request.
     *
     * @return the request headers to use in the request
     */
    public Map<String, String> getRequestHeaders() {
        return requestHeaders;
    }

    /**
     * Sets the request headers to use in the request.
     *
     * @param headers the request headers to use in the request
     */
    public void setRequestHeaders(Map<String, String> headers) {
        this.requestHeaders = headers;
    }

    /**
     * Gets the read timeout.
     * <p>
     * The read timeout is used to create input stream with a limited time to receive data from resource.
     *
     * @return the read timeout in milliseconds
     */
    public int getReadTimeout() {
        return readTimeout;
    }

    /**
     * Sets the read timeout.
     * <p>
     * The read timeout is used to create input stream with a limited time to receive data from resource.
     *
     * @param readTimeout the read timeout in milliseconds
     *
     * @return the {@link IResourceRetriever} instance
     */
    public IResourceRetriever setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public InputStream getInputStreamByUrl(URL url) throws IOException {
        if (urlFilter(url)) {
            return new LimitedInputStream(UrlUtil
                    .getInputStreamOfFinalConnection(url, connectTimeout, readTimeout, requestHeaders),
                    resourceSizeByteLimit);
        }
        LOGGER.warn(() -> MessageFormatUtil.format(IoLogMessageConstant.RESOURCE_WITH_GIVEN_URL_WAS_FILTERED_OUT, url));
        return null;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public byte[] getByteArrayByUrl(URL url) throws IOException {
        try (InputStream stream = getInputStreamByUrl(url)) {
            if (stream != null) {
                return StreamUtil.inputStreamToArray(stream);
            }
            return null;
        } catch (ReadingByteLimitException ex) {
            LOGGER.warn(() -> MessageFormatUtil.format(
                    IoLogMessageConstant.UNABLE_TO_RETRIEVE_RESOURCE_WITH_GIVEN_RESOURCE_SIZE_BYTE_LIMIT,
                    url, resourceSizeByteLimit));
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public InputStream get(URL url, byte[] request, Map<String, String> headers) throws IOException {
        HashMap<String, String> finalHeaders = new HashMap<String, String>();
        if (requestHeaders != null) {
            finalHeaders.putAll(requestHeaders);
        }
        if (headers != null) {
            finalHeaders.putAll(headers);
        }
        if (urlFilter(url)) {
            return new LimitedInputStream(UrlUtil.get(url, request, finalHeaders, connectTimeout, readTimeout),
                    resourceSizeByteLimit);
        }
        LOGGER.warn(() -> MessageFormatUtil.format(IoLogMessageConstant.RESOURCE_WITH_GIVEN_URL_WAS_FILTERED_OUT, url));
        return null;
    }

    /**
     * Method for filtering resources by URL.
     * <p>
     * The default implementation allows for all URLs. Override this method if want to set filtering.
     *
     * @param url the source URL
     * @return true if the resource can be retrieved and false otherwise
     */
    protected boolean urlFilter(URL url) {
        return true;
    }
}
