/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.font.cmap;

import com.itextpdf.io.util.IntHashtable;

/**
 * Class represents real codepoint-CID mapping without any additional manipulation.
 *
 * <p>
 * See {@link CMapCidToCodepoint} for CID-codepoint representation.
 */
public class CMapCodepointToCid extends AbstractCMap {

    private final IntHashtable map;

    /**
     * Creates an empty character code to CID map.
     */
    public CMapCodepointToCid() {
        map = new IntHashtable();
    }

    /**
     * Creates a map by reversing a CID to code mapping.
     *
     * @param reverseMap the CID to code mapping to reverse
     */
    public CMapCodepointToCid(CMapCidToCodepoint reverseMap) {
        map = reverseMap.getReversMap();
    }

    @Override
    void addChar(String mark, CMapObject code) {
        if (code.isNumber()) {
            byte[] ser = decodeStringToByte(mark);
            int byteCode = 0;
            for (byte b: ser) {
                byteCode <<= 8;
                byteCode += b & 0xff;
            }
            map.put(byteCode, (int) code.getValue());
        }
    }

    /**
     * Looks up the CID assigned to a character code.
     *
     * @param codepoint the integer representation of the encoded character code
     *
     * @return the mapped CID, or {@code 0} when absent
     */
    public int lookup(int codepoint) {
        return this.map.get(codepoint);
    }
}
