/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.font;

import com.itextpdf.commons.logs.LazyLogger;
import com.itextpdf.io.font.cmap.CMapCidToCodepoint;
import com.itextpdf.io.font.cmap.CMapCodepointToCid;
import com.itextpdf.io.font.cmap.CMapLocationFromBytes;
import com.itextpdf.io.font.cmap.CMapParser;
import com.itextpdf.io.logs.IoLogMessageConstant;
import com.itextpdf.io.source.ByteBuffer;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Class representing CMap encoding in pdf document.
 */
public class CMapEncoding {

    private static final LazyLogger LOGGER = new LazyLogger(CMapEncoding.class);

    private static final List<byte[]> IDENTITY_H_V_CODESPACE_RANGES = Arrays.asList(new byte[] {0, 0}, new byte[] {(byte)0xff, (byte)0xff});

    private final String cmap;
    private String uniMap;

    // true if CMap is Identity-H/V
    private boolean isDirect;

    private CMapCidToCodepoint cid2Code;

    private CMapCodepointToCid code2Cid;

    private List<byte[]> codeSpaceRanges;

    /**
     * Creates a new CMap encoding.
     *
     * @param cmap CMap name
     */
    public CMapEncoding(String cmap) {
        this.cmap = cmap;
        if (cmap.equals(PdfEncodings.IDENTITY_H) || cmap.equals(PdfEncodings.IDENTITY_V)) {
            isDirect = true;
        }
        // Actually this constructor is only called for Identity-H/V cmaps currently.
        // Even for hypothetical case of non-Identity-H/V, let's use Identity-H/V ranges (two byte ranges) for compatibility with previous behavior
        this.codeSpaceRanges = IDENTITY_H_V_CODESPACE_RANGES;
    }

    /**
     * Creates a new CMap encoding.
     *
     * @param cmap CMap name
     * @param uniMap CMap to convert Unicode value to CID
     */
    public CMapEncoding(String cmap, String uniMap) {
        this.cmap = cmap;
        this.uniMap = uniMap;
        if (cmap.equals(PdfEncodings.IDENTITY_H) || cmap.equals(PdfEncodings.IDENTITY_V)) {
            isDirect = true;
            this.codeSpaceRanges = IDENTITY_H_V_CODESPACE_RANGES;
        } else {
            cid2Code = CjkResourceLoader.getCidToCodepointCmap(cmap);
            code2Cid = CMapEncoding.getCodeToCidCmap(cmap, cid2Code);
            this.codeSpaceRanges = cid2Code.getCodeSpaceRanges();
        }
    }

    /**
     * Creates a new CMap encoding.
     *
     * @param cmap CMap name
     * @param cmapBytes CMap binary data
     */
    public CMapEncoding(String cmap, byte[] cmapBytes) {
        this.cmap = cmap;
        cid2Code = new CMapCidToCodepoint();
        try {
            CMapParser.parseCid(cmap, cid2Code, new CMapLocationFromBytes(cmapBytes));
            code2Cid = CMapEncoding.getCodeToCidCmap(cmap, cid2Code);
            this.codeSpaceRanges = cid2Code.getCodeSpaceRanges();
        } catch (IOException e) {
            LOGGER.error(() -> IoLogMessageConstant.FAILED_TO_PARSE_ENCODING_STREAM);
        }
    }

    /**
     * Checks if CMap is direct or indirect pdf object
     *
     * @return {@code true} if direct, {@code false} otherwise
     */
    public boolean isDirect() {
        return isDirect;
    }

    /**
     * Checks if CMap to convert Unicode value to CID is present.
     *
     * @return {@code true} if present, {@code false} otherwise
     */
    public boolean hasUniMap() {
        return uniMap != null && uniMap.length() > 0;
    }

    /**
     * Gets string identifying the issuer of the character collection.
     *
     * @return name of the issuer
     */
    public String getRegistry() {
        if (isDirect()) {
            return "Adobe";
        } else {
            return cid2Code.getRegistry();
        }
    }

    /**
     * Gets string that uniquely names the character collection within the specified registry.
     *
     * @return character collection name
     */
    public String getOrdering() {
        if (isDirect()) {
            return "Identity";
        } else {
            return cid2Code.getOrdering();
        }
    }

    /**
     * Gets the supplement number of the character collection
     *
     * @return supplement number
     */
    public int getSupplement() {
        if (isDirect()) {
            return 0;
        } else {
            return cid2Code.getSupplement();
        }
    }

    /**
     * Gets CMap name which converts Unicode value to CID.
     *
     * @return CMap name
     */
    public String getUniMapName() {
        return uniMap;
    }

    /**
     * Gets CMap name.
     *
     * @return CMap name
     */
    public String getCmapName() {
        return cmap;
    }

    /**
     * Checks whether the {@link CMapEncoding} was built with corresponding cmap name.
     *
     * @param cmap a CMAP
     * @return {@code true}, if the CMapEncoding was built with the cmap, {@code false} otherwise.
     */
    public boolean isBuiltWith(String cmap) {
        return Objects.equals(cmap, this.cmap);
    }

    /**
     * Gets CMap bytes by CID.
     *
     * @param cid id of the CMap
     *
     * @return cmap as byte array
     */
    public byte[] getCmapBytes(int cid) {
        int length = getCmapBytesLength(cid);
        byte[] result = new byte[length];
        fillCmapBytes(cid, result, 0);
        return result;
    }

    /**
     * Encodes a CID into the supplied byte array.
     *
     * @param cid    character identifier to encode
     * @param array  destination array
     * @param offset destination offset
     *
     * @return new destination offset
     */
    public int fillCmapBytes(int cid, byte[] array, int offset) {
        if (isDirect) {
            array[offset++] = (byte)((cid & 0xff00) >> 8);
            array[offset++] = (byte)(cid & 0xff);
        } else {
            byte[] bytes = cid2Code.lookup(cid);
            for (int i = 0; i < bytes.length; i++) {
                array[offset++] = bytes[i];
            }
        }
        return offset;
    }

    /**
     * Appends the encoded form of a CID to a byte buffer.
     *
     * @param cid    character identifier to encode
     * @param buffer destination buffer
     */
    public void fillCmapBytes(int cid, ByteBuffer buffer) {
        if (isDirect) {
            buffer.append((byte)((cid & 0xff00) >> 8));
            buffer.append((byte)(cid & 0xff));
        } else {
            byte[] bytes = cid2Code.lookup(cid);
            buffer.append(bytes);
        }
    }

    /**
     * Gets the number of bytes required to encode a CID.
     *
     * @param cid character identifier to encode
     *
     * @return number of bytes required to encode a CID
     */
    public int getCmapBytesLength(int cid) {
        if (isDirect) {
            return 2;
        } else {
            return cid2Code.lookup(cid).length;
        }
    }

    /**
     * Converts a CMap code to its CID.
     *
     * @param cmapCode CMap code
     *
     * @return mapped CID
     */
    public int getCidCode(int cmapCode) {
        if (isDirect) {
            return cmapCode;
        } else {
            return code2Cid.lookup(cmapCode);
        }
    }

    /**
     * Gets the CMap code space ranges.
     *
     * @return list of low/high byte array pairs used by this encoding
     */
    public List<byte[]> getCodeSpaceRanges() {
        return codeSpaceRanges;
    }

    private static CMapCodepointToCid getCodeToCidCmap(String cmap, CMapCidToCodepoint cid2Code) {
        try {
            return CjkResourceLoader.getCodepointToCidCmap(cmap);
        } catch (com.itextpdf.io.exceptions.IOException ex) {
            // if not found, fall back to reversing
            return new CMapCodepointToCid(cid2Code);
        }
    }
}
