/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.io.font;

import com.itextpdf.io.font.otf.Glyph;

class GidAwareGlyph extends Glyph {
    private int gid;

    /**
     * Creates a glyph with an initially unset glyph identifier.
     *
     * @param code    the character code
     * @param width   the glyph width
     * @param unicode the Unicode code point
     * @param bbox    the glyph bounding box
     */
    public GidAwareGlyph(int code, int width, int unicode, int[] bbox) {
        super(code, width, unicode, bbox);
    }

    /**
     * Sets the font glyph identifier.
     *
     * @param index the glyph identifier
     */
    public void setGid(int index) {
        this.gid = index;
    }

    /**
     * Returns the font glyph identifier.
     *
     * @return the glyph identifier
     */
    public int getGid() {
        return gid;
    }
}
