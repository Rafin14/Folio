/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.kernel.pdf;

import com.itextpdf.commons.logs.LazyLogger;
import com.itextpdf.commons.utils.MessageFormatUtil;
import com.itextpdf.kernel.exceptions.KernelExceptionMessageConstant;
import com.itextpdf.kernel.exceptions.MemoryLimitsAwareException;
import com.itextpdf.kernel.logs.KernelLogMessageConstant;

/**
 * Enforces configurable limits intended to protect PDF reading/parsing against excessive memory consumption.
 *
 * <p>The handler is primarily used during decoding (decompression) of PDF streams, but also guards against other
 * potentially unbounded structures during reading, e.g. cross-reference (xref) table growth and per-page XObject usage.
 *
 * <h2>How it is configured</h2>
 * <p>A configured handler can be set on {@link ReaderProperties} and will be used by {@link PdfReader} when opening
 * a document.
 *
 * <p>Note that {@link MemoryLimitsAwareHandler} must not be shared between different {@link PdfDocument} instances.
 *
 * @see ReaderProperties#setMemoryLimitsAwareHandler(MemoryLimitsAwareHandler)
 * @see MemoryLimitsAwareException
 */
public class MemoryLimitsAwareHandler {

    private static final LazyLogger LOGGER = new LazyLogger(MemoryLimitsAwareHandler.class);

    private static final int SINGLE_SCALE_COEFFICIENT = 100;
    private static final int SUM_SCALE_COEFFICIENT = 500;

    private static final int MAX_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE = 50000000;
    private static final int MIN_LIMIT_FOR_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE = 500000;
    private static final int SINGLE_DECOMPRESSED_PDF_STREAM_MIN_SIZE = Integer.MAX_VALUE / 100;
    private static final long SUM_OF_DECOMPRESSED_PDF_STREAMS_MIN_SIZE = Integer.MAX_VALUE / 20;
    private static final long MAX_X_OBJECTS_SIZE_PER_PAGE = 1024L*1024L*1024L*3;

    private int maxSizeOfSingleDecompressedPdfStream;
    private long maxSizeOfDecompressedPdfStreamsSum;
    private int maxNumberOfElementsInXrefStructure;

    private long maxXObjectsSizePerPage;

    private long allMemoryUsedForDecompression = 0;
    private long memoryUsedForCurrentPdfStreamDecompression = 0;

    boolean considerCurrentPdfStream = false;

    /**
     * Creates a {@link MemoryLimitsAwareHandler} to handle decompression of PDF streams and other memory-related limits
     * during reading.
     */
    public MemoryLimitsAwareHandler() {
        this(SINGLE_DECOMPRESSED_PDF_STREAM_MIN_SIZE, SUM_OF_DECOMPRESSED_PDF_STREAMS_MIN_SIZE,
                MAX_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE, MAX_X_OBJECTS_SIZE_PER_PAGE);
    }

    /**
     * Creates a {@link MemoryLimitsAwareHandler} with calculated memory limits
     * for decompression and xref structures based on the provided document size.
     *
     * @param documentSize the size of the document (in bytes)
     */
    public MemoryLimitsAwareHandler(long documentSize) {
        this((int) calculateDefaultParameter(documentSize, SINGLE_SCALE_COEFFICIENT,
                SINGLE_DECOMPRESSED_PDF_STREAM_MIN_SIZE), calculateDefaultParameter(documentSize, SUM_SCALE_COEFFICIENT,
                SUM_OF_DECOMPRESSED_PDF_STREAMS_MIN_SIZE), calculateMaxElementsInXref(documentSize), MAX_X_OBJECTS_SIZE_PER_PAGE);
    }

    private MemoryLimitsAwareHandler(int maxSizeOfSingleDecompressedPdfStream, long maxSizeOfDecompressedPdfStreamsSum,
            int maxNumberOfElementsInXrefStructure, long maxXObjectsSizePerPage) {
        this.maxSizeOfSingleDecompressedPdfStream = maxSizeOfSingleDecompressedPdfStream;
        this.maxSizeOfDecompressedPdfStreamsSum = maxSizeOfDecompressedPdfStreamsSum;
        this.maxNumberOfElementsInXrefStructure = maxNumberOfElementsInXrefStructure;
        this.maxXObjectsSizePerPage = maxXObjectsSizePerPage;
    }

    /**
     * Creates a new instance of {@link MemoryLimitsAwareHandler} by copying settings from this instance
     * of {@link MemoryLimitsAwareHandler}.
     *
     * @return a new instance of {@link MemoryLimitsAwareHandler}
     */
    public MemoryLimitsAwareHandler createNewInstance() {
        MemoryLimitsAwareHandler to = new MemoryLimitsAwareHandler();
        to.maxSizeOfSingleDecompressedPdfStream = this.maxSizeOfSingleDecompressedPdfStream;
        to.maxSizeOfDecompressedPdfStreamsSum = this.maxSizeOfDecompressedPdfStreamsSum;
        to.maxNumberOfElementsInXrefStructure = this.maxNumberOfElementsInXrefStructure;
        to.maxXObjectsSizePerPage = this.maxXObjectsSizePerPage;
        if (this.getClass() != MemoryLimitsAwareHandler.class) {
            LOGGER.warn(() -> KernelLogMessageConstant.MEMORYLIMITAWAREHANDLER_OVERRIDE_CREATENEWINSTANCE_METHOD);
        }

        return to;
    }

    /**
     * Returns the maximum allowed size (in bytes) of a single decompressed PDF stream.
     *
     * @return maximum allowed size of a single decompressed stream in bytes
     */
    public int getMaxSizeOfSingleDecompressedPdfStream() {
        return maxSizeOfSingleDecompressedPdfStream;
    }

    /**
     * Sets the maximum allowed size which can be occupied by a single decompressed PDF stream.
     * This value correlates with maximum heap size. This value should not exceed limit of the heap size.
     *
     * <p>iText will throw an exception if during decompression a PDF stream which was identified as
     * requiring memory limits awareness occupies more memory than allowed.
     *
     * @param maxSizeOfSingleDecompressedPdfStream the maximum allowed size which can be occupied by a single
     *                                             decompressed PDF stream
     *
     * @return this {@link MemoryLimitsAwareHandler} instance
     * @see MemoryLimitsAwareHandler#isMemoryLimitsAwarenessRequiredOnDecompression(PdfArray)
     */
    public MemoryLimitsAwareHandler setMaxSizeOfSingleDecompressedPdfStream(int maxSizeOfSingleDecompressedPdfStream) {
        this.maxSizeOfSingleDecompressedPdfStream = maxSizeOfSingleDecompressedPdfStream;
        return this;
    }

    /**
     * Gets the maximum allowed size which can be occupied by all decompressed PDF streams.
     *
     * @return the maximum allowed size value which streams may occupy
     */
    public long getMaxSizeOfDecompressedPdfStreamsSum() {
        return maxSizeOfDecompressedPdfStreamsSum;
    }

    /**
     * Sets the maximum allowed size which can be occupied by all decompressed PDF streams.
     * This value can be limited by the maximum expected PDF file size when it's completely decompressed.
     * Setting this value correlates with the maximum processing time spent on document reading
     *
     * <p>iText will throw an exception if during decompression of PDF streams which were identified as
     * requiring memory limits awareness occupy more memory than allowed.
     *
     * <p>
     * Note that if a PDF stream is decompressed multiple times, it is counted multiple times for this limit.
     *
     * @param maxSizeOfDecompressedPdfStreamsSum he maximum allowed size which can be occupied by all decompressed PDF
     *                                           streams
     *
     * @return this {@link MemoryLimitsAwareHandler} instance
     * @see MemoryLimitsAwareHandler#isMemoryLimitsAwarenessRequiredOnDecompression(PdfArray)
     */
    public MemoryLimitsAwareHandler setMaxSizeOfDecompressedPdfStreamsSum(long maxSizeOfDecompressedPdfStreamsSum) {
        this.maxSizeOfDecompressedPdfStreamsSum = maxSizeOfDecompressedPdfStreamsSum;
        return this;
    }

    /**
     * Performs a check if the {@link PdfStream} with provided setup of the filters requires
     * memory limits awareness during decompression.
     *
     * @param filters is an {@link PdfArray} of names of filters
     *
     * @return {@code true} if PDF stream is suspicious and {@code false} otherwise
     *
     * @deprecated to be made protected and accept stream dictionary instead of {@link PdfArray} of filters
     */
    @Deprecated
    public boolean isMemoryLimitsAwarenessRequiredOnDecompression(PdfArray filters) {
        return true;
    }

    /**
     * Gets maximum number of elements in xref structure.
     *
     * @return maximum number of elements in xref structure
     */
    public int getMaxNumberOfElementsInXrefStructure() {
        return maxNumberOfElementsInXrefStructure;
    }

    /**
     * Gets maximum page size.
     *
     * @return maximum page size
     *
     * @deprecated in favor of {@link MemoryLimitsAwareHandler#setMaxSizeOfDecompressedPdfStreamsSum}
     */
    @Deprecated
    public long getMaxXObjectsSizePerPage() {
        return maxXObjectsSizePerPage;
    }

    /**
     * Sets maximum page size.
     *
     * @param maxPageSize maximum page size
     *
     * @deprecated in favor of {@link MemoryLimitsAwareHandler#setMaxSizeOfDecompressedPdfStreamsSum}
     */
    @Deprecated
    public void setMaxXObjectsSizePerPage(long maxPageSize) {
        this.maxXObjectsSizePerPage = maxPageSize;
    }

    /**
     * Sets maximum number of elements in xref structure.
     *
     * @param maxNumberOfElementsInXrefStructure maximum number of elements in xref structure
     */
    public void setMaxNumberOfElementsInXrefStructure(int maxNumberOfElementsInXrefStructure) {
        this.maxNumberOfElementsInXrefStructure = maxNumberOfElementsInXrefStructure;
    }

    /**
     * Performs a check of possible extension of xref structure.
     *
     * @param requestedCapacity capacity to which we need to expand xref array
     */
    public void checkIfXrefStructureExceedsTheLimit(int requestedCapacity) {
        // Objects in xref structures are using 1-based indexes, so to store maxNumberOfElementsInXrefStructure
        // amount of elements we need maxNumberOfElementsInXrefStructure + 1 capacity.
        if (requestedCapacity - 1 > maxNumberOfElementsInXrefStructure || requestedCapacity < 0) {
            throw new MemoryLimitsAwareException(KernelExceptionMessageConstant.XREF_STRUCTURE_SIZE_EXCEEDED_THE_LIMIT);
        }
    }

    /**
     * Checks if page size limit is exceeded.
     *
     * @param totalPageSize total size of the read page content
     *
     * @deprecated in favor of {@link MemoryLimitsAwareHandler#setMaxSizeOfDecompressedPdfStreamsSum}. Also get rid of
     * its usage in {@link com.itextpdf.kernel.pdf.canvas.parser.PdfCanvasProcessor}
     */
    @Deprecated
    public void checkIfPageSizeExceedsTheLimit(long totalPageSize) {
        if (totalPageSize > maxXObjectsSizePerPage) {
            throw new MemoryLimitsAwareException(KernelExceptionMessageConstant.TOTAL_XOBJECT_SIZE_ONE_PAGE_EXCEEDED_THE_LIMIT);
        }
    }

    /**
     * Calculate max number of elements allowed in xref table based on the size of the document, achieving max limit at 100MB.
     *
     * @param documentSizeInBytes document size in bytes
     *
     * @return calculated limit
     */
    protected static int calculateMaxElementsInXref(long documentSizeInBytes) {
        final int maxDocSizeForMaxLimit = MAX_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE / MIN_LIMIT_FOR_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE;
        final int documentSizeInMb = (int) Math.max(1, Math.min(documentSizeInBytes / (1024 * 1024), maxDocSizeForMaxLimit));
        return documentSizeInMb * MIN_LIMIT_FOR_NUMBER_OF_ELEMENTS_IN_XREF_STRUCTURE;
    }

    /**
     * Considers the number of bytes which are occupied by the decompressed PDF stream.
     * If memory limits have not been faced, throws an exception.
     *
     * @param numOfOccupiedBytes the number of bytes which are occupied by the decompressed PDF stream
     *
     * @return this {@link MemoryLimitsAwareHandler} instance.
     * @see MemoryLimitsAwareException
     */
    MemoryLimitsAwareHandler considerBytesOccupiedByDecompressedPdfStream(long numOfOccupiedBytes) {
        if (considerCurrentPdfStream && memoryUsedForCurrentPdfStreamDecompression < numOfOccupiedBytes) {
            memoryUsedForCurrentPdfStreamDecompression = numOfOccupiedBytes;
            if (memoryUsedForCurrentPdfStreamDecompression > maxSizeOfSingleDecompressedPdfStream) {
                throw new MemoryLimitsAwareException(MessageFormatUtil.format(
                        KernelExceptionMessageConstant.DURING_DECOMPRESSION_SINGLE_STREAM_OCCUPIED_MORE_MEMORY_THAN_ALLOWED,
                        maxSizeOfSingleDecompressedPdfStream / 1024 / 1024 + "MB"));
            }
        }
        return this;
    }

    /**
     * Begins handling of current PDF stream decompression.
     *
     * @return this {@link MemoryLimitsAwareHandler} instance
     */
    MemoryLimitsAwareHandler beginDecompressedPdfStreamProcessing() {
        ensureCurrentStreamIsReset();
        considerCurrentPdfStream = true;
        return this;
    }

    /**
     * Ends handling of current pdf stream decompression.
     * If memory limits have not been faced, throws an exception.
     *
     * @return this {@link MemoryLimitsAwareHandler} instance
     * @see MemoryLimitsAwareException
     */
    MemoryLimitsAwareHandler endDecompressedPdfStreamProcessing() {
        allMemoryUsedForDecompression += memoryUsedForCurrentPdfStreamDecompression;
        if (allMemoryUsedForDecompression > maxSizeOfDecompressedPdfStreamsSum) {
            throw new MemoryLimitsAwareException(MessageFormatUtil.format(
                    KernelExceptionMessageConstant.DURING_DECOMPRESSION_MULTIPLE_STREAMS_IN_SUM_OCCUPIED_MORE_MEMORY_THAN_ALLOWED,
                    maxSizeOfDecompressedPdfStreamsSum / 1024 / 1024 + "MB"));
        }
        ensureCurrentStreamIsReset();
        considerCurrentPdfStream = false;
        return this;
    }

    long getAllMemoryUsedForDecompression() {
        return allMemoryUsedForDecompression;
    }

    private static long calculateDefaultParameter(long documentSize, int scale, long min) {
        long result = documentSize * scale;
        if (result < min) {
            result = min;
        }
        if (result > min * scale) {
            result = min * scale;
        }
        return result;
    }

    private void ensureCurrentStreamIsReset() {
        memoryUsedForCurrentPdfStreamDecompression = 0;
    }
}
