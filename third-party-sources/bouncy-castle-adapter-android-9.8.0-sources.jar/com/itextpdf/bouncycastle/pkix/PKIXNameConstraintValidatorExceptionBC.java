/*
    This file is part of the iText (R) project.
    Copyright (c) 1998-2026 Apryse Group NV
    Authors: Apryse Software.

    This program is offered under a commercial and under the AGPL license.
    For commercial licensing, contact us at https://itextpdf.com/sales.  For AGPL licensing, see below.

    AGPL licensing:
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU Affero General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU Affero General Public License for more details.

    You should have received a copy of the GNU Affero General Public License
    along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */
package com.itextpdf.bouncycastle.pkix;

import com.itextpdf.commons.bouncycastle.asn1.pkix.AbstractPKIXNameConstraintValidatorException;
import org.bouncycastle.pkix.PKIXNameConstraintValidatorException;
import org.bouncycastle.tsp.TSPException;

import java.util.Objects;

/**
 * Wrapper class for {@link PKIXNameConstraintValidatorException}.
 */
public class PKIXNameConstraintValidatorExceptionBC extends AbstractPKIXNameConstraintValidatorException {
    private final PKIXNameConstraintValidatorException nameConstraintValidatorException;

    /**
     * Creates new wrapper instance for {@link TSPException}.
     *
     * @param nameConstraintValidatorException {@link TSPException} to be wrapped
     */
    public PKIXNameConstraintValidatorExceptionBC(
            PKIXNameConstraintValidatorException nameConstraintValidatorException) {
        super();
        this.nameConstraintValidatorException = nameConstraintValidatorException;
    }

    /**
     * Gets actual org.bouncycastle object being wrapped.
     *
     * @return wrapped {@link PKIXNameConstraintValidatorException}.
     */
    public PKIXNameConstraintValidatorException getNameConstraintValidatorException() {
        return nameConstraintValidatorException;
    }

    /**
     * Indicates whether some other object is "equal to" this one. Compares wrapped objects.
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        PKIXNameConstraintValidatorExceptionBC that = (PKIXNameConstraintValidatorExceptionBC) o;
        return Objects.equals(nameConstraintValidatorException, that.nameConstraintValidatorException);
    }

    /**
     * Returns a hash code value based on the wrapped object.
     */
    @Override
    public int hashCode() {
        return Objects.hash(nameConstraintValidatorException);
    }

    /**
     * Delegates {@code toString} method call to the wrapped object.
     */
    @Override
    public String toString() {
        return nameConstraintValidatorException.toString();
    }

    /**
     * Delegates {@code getMessage} method call to the wrapped exception.
     */
    @Override
    public String getMessage() {
        return nameConstraintValidatorException.getMessage();
    }
}
